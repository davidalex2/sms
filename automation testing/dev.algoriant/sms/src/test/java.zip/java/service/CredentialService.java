package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import model.Role;
import model.RolePojo;
import java.util.HashSet;
import java.util.Set;

public class CredentialService {
    public static void main(String[] args) throws UnirestException, JsonProcessingException {
        CredentialService credentialService=new CredentialService();
        credentialService.getUsername_Password();
    }
    public void getUsername_Password() throws JsonProcessingException, UnirestException {
        Role roles=new Role();
        roles.setRole("admin");
        roles.setRoleDesc("for admin");
        String role= new ObjectMapper().writeValueAsString(roles);
        HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.post("http://192.168.1.37:8080/createRole").header("Content-Type","application/json").body(role).asJson();
        System.out.println(jsonNodeHttpResponse.getBody());
        RolePojo rolePojo=new RolePojo();
        rolePojo.setPassword("admin");
        rolePojo.setUsername("admin12");
        Set<Role> set=new HashSet<>();
        set.add(roles);
        rolePojo.setRoles(set);
        String roleJson=new ObjectMapper().writeValueAsString(rolePojo);
        HttpResponse<JsonNode> jsonNodeHttpResponse1= Unirest.post("http://192.168.1.37:8080/saveUser").header("Content-Type","application/json").body(roleJson).asJson();
        System.out.println(jsonNodeHttpResponse1.getBody());
    }
}
