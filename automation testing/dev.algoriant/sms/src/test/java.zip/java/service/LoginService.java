package service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import model.AccessToken;
import model.Authentication;

import java.io.*;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class LoginService {
    public  static void main(String[] arg) throws UnirestException, IOException {
        LoginService loginService=new LoginService();
        AccessToken accessToken=loginService.loginDetails();
        System.out.println("Token "+accessToken.getAccessToken());
        System.out.println("UserName "+accessToken.getUsername());
    }
    public AccessToken loginDetails() throws UnirestException, IOException {
        Authentication authentication=new Authentication();
        authentication.setPassword("admin");
        authentication.setUsername("admin12");
        String details=new ObjectMapper().writeValueAsString(authentication);
        HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.post("http://192.168.1.39:8080/auth/login")
                .header("Content-type","application/json").body(details).asJson();
        ObjectMapper mapper=new ObjectMapper();
        return mapper.readValue((jsonNodeHttpResponse.getBody()).toString(), AccessToken.class);

    }
}
