package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import model.RolePojo;
import model.Role;
import model.Student;


import java.util.*;
import java.util.stream.Collectors;

//sudo kill -9 $(sudo kill lsof -t -i:8080) to stop the server
class StudentService {
    final static String token="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbjEyIiwiaXNzIjoiVXNlciIsInJvbGVzIjoiW2FkbWluXSIsImlhdCI6MTY5MjE3NzM0NCwiZXhwIjoxNjkyMjYzNzQ0fQ.Yb_LNTqQBcNSKMJtkp7fCYq3tYcKdOjjOxbzdb7x5tw1GqGPsq9AFaYz4E3A_4JP-6-KYzuyrrAJ-ry2Dzt4yA";
    public static void main(String[] args) throws JsonProcessingException, UnirestException {
        StudentService studentService = new StudentService();
        studentService.getAllStudent();
    }
    public void createStudent() throws JsonProcessingException, UnirestException {
        Student student=new Student();
        student.setName("david");
        student.setEmail("davidalex@gmail.com");
        student.setPhoneno(978654674);
        String studentDetails=new ObjectMapper().writeValueAsString(student);
        HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.post("http://192.168.1.39:8080/student/createStudent")
                .header("Content-Type","application/json").header("Authorization","Bearer "+token).body(studentDetails).asJson();
        System.out.println(jsonNodeHttpResponse.getBody());
    }
    public void updateStudent() throws JsonProcessingException, UnirestException {
        Student student=new Student();
        student.setName("mani");
        student.setEmail("mani@gmail.com");
        student.setPhoneno(123456789);
        student.setId(10);
        String studentDetails=new ObjectMapper().writeValueAsString(student);
        HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.put("http://192.168.1.39:8080/student/modifyStudentRecord/10")
                .header("Content-Type","application/json").header("Authorization","Bearer "+token).body(studentDetails).asJson();
        System.out.println(jsonNodeHttpResponse.getBody());
    }
    public void removeStudent()  {
        try {
            HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.delete("http://192.168.1.39:8080/student/removeStudent/16")
                    .header("Content-Type","application/json").header("Authorization","Bearer "+token).asJson();
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }
//System.out.println(jsonNodeHttpResponse1.getBody());
    }
    public void getStudent() {
        try {
            HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.get("http://192.168.1.39:8080/student/getStudent/14")
                    .header("Content-Type","application/json").header("Authorization","Bearer "+token).asJson();
            System.out.println(jsonNodeHttpResponse.getBody());
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }
    }
    public void getAllStudent() {
        try {
         HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.get("http://192.168.1.39:8080/student/getAllStudent")
                .header("Content-Type","application/json").header("Authorization","Bearer "+token).asJson();
         System.out.println(jsonNodeHttpResponse.getBody());
      } catch (UnirestException e) {
        throw new RuntimeException(e);
    }

    }

}


