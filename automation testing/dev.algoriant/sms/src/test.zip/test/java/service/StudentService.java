package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import model.RoleForDesc;
import model.RolePojo;
import model.Student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

//sudo kill -9 $(sudo kill lsof -t -i:8080) to stop the server

public class StudentService {
    public static void main(String[] args) throws JsonProcessingException {
        StudentService studentService=new StudentService();
        studentService.saveUserFunction();
    }
    public void saveUserFunction() throws JsonProcessingException {
        Student student=new Student();
        student.setName("alex");
        student.setEmail("davidalex@gmail.com");
        student.setPhoneNo(9003592509l);
        String json = new ObjectMapper().writeValueAsString(student);
        RoleForDesc roleForDesc=new RoleForDesc();
        roleForDesc.setRole("admin");
        roleForDesc.setRoleDesc("for admin");
        List<RoleForDesc> list= Collections.singletonList(roleForDesc);
       //list.add(roleForDesc);
        RolePojo rolePojo=new RolePojo();
        rolePojo.setUserName("admin123");
        rolePojo.setPassword("admin");
        rolePojo.setRoleForDescList(list);
        String roles= new ObjectMapper().writeValueAsString(roleForDesc);
        String roleJson=new ObjectMapper().writeValueAsString(rolePojo);
        try {
            HttpResponse<JsonNode> jsonNodeHttpResponse= Unirest.post("http://192.168.1.37:8080/createRole").header("Content-Type","application/json").body(roles).asJson();
            HttpResponse<JsonNode> jsonNodeHttpResponse1= Unirest.post("http://192.168.1.38:8080/saveUser").header("Content-Type","application/json").body(roleJson).asJson();
            //HttpResponse<JsonNode> jsonNodeHttpResponse3=Unirest.get("http://192.168.1.37:8080/login").basicAuth("admin123","admin").asJson();
            //System.out.println(jsonNodeHttpResponse2.getBody());
            System.out.println(jsonNodeHttpResponse.getBody());
            System.out.println(jsonNodeHttpResponse1.getBody());
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }
    }
    }


