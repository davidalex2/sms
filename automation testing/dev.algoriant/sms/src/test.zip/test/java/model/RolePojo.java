package model;

import java.util.Arrays;
import java.util.List;
public class RolePojo {

    private String userName;
    private String password;
    private String role,roleDesc;
    private List<RoleForDesc> roleForDescList;
    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


    public List<RoleForDesc> getRoleForDescList() {
        return roleForDescList;
    }
    public void setRoleForDescList(List<RoleForDesc> roleForDescList) {
        this.roleForDescList = roleForDescList;
    }
    public RolePojo() {}
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}
