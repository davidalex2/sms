package model;

public class Student {
    private String name,email;
    private long phoneNo;
    public Student() {
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }
    public void setEmail(String email) {
        this.email=email;
    }
    public String getEmail() {
        return email;
    }
    public void setPhoneNo(long phoneNo) {
        this.phoneNo=phoneNo;
    }
    public long getPhoneNo() {
        return phoneNo;
    }
    public  String toString() {
        return name+" "+email+" "+phoneNo;
    }
}
